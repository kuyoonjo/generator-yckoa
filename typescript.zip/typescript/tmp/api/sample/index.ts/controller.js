"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const Utils = require("../../");
class Controller extends Utils.Controller {
    // Gets a list of Models
    index(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let paginateResult = yield Utils.paginate(this.model, req);
                res.status(200).json(paginateResult);
            }
            catch (e) {
                Utils.handleError(res, e);
            }
        });
    }
    // Gets a single Model from the DB
    show(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let entity = yield Utils.show(this.model, req);
                Utils.validateEntity(entity);
                res.status(200).json(entity);
            }
            catch (e) {
                Utils.handleError(res, e);
            }
        });
    }
    // Creates a new Model in the DB
    create(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let entity = Utils.createEntity(this.model, req);
                Utils.attachFile(req, entity, 'image');
                yield entity.save();
                res.status(201).json(entity);
            }
            catch (e) {
                Utils.handleError(res, e);
            }
        });
    }
    // Updates an existing Model in the DB
    update(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                delete req.body._id;
                let entity = yield this.model.findById(req.params.id).exec();
                Utils.validateEntity(entity);
                Utils.patchUpdates(entity, req.body);
                Utils.attachFile(req, entity, 'image');
                yield entity.save();
                res.status(201).json(entity);
            }
            catch (e) {
                Utils.handleError(res, e);
            }
        });
    }
    // Deletes a Model from the DB
    destroy(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let entity = yield this.model.findById(req.params.id).exec();
                Utils.validateEntity(entity);
                yield entity.remove();
                res.status(204).end();
            }
            catch (e) {
                Utils.handleError(res, e);
            }
        });
    }
}
exports.default = new Controller(model_1.default);
