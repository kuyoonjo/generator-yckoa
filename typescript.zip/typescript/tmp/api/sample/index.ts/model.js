"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const paginate = require("mongoose-paginate");
exports.default = mongoose.model('Setting', new mongoose.Schema({
    name: String,
    value: String
})
    .plugin(paginate));
