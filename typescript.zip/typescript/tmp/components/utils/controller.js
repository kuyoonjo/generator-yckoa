"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Controller {
    constructor(model) {
        this.model = model;
        for (let method of ['index', 'show', 'create', 'update', 'destroy']) {
            this[method] = this[method].bind(this);
        }
    }
}
exports.Controller = Controller;
