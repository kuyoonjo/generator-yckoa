"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const boom = require("boom");
const _1 = require("../");
function handleError(ctx, error, statusCode = 500) {
    console.error(error);
    let be;
    if (error instanceof Error) {
        let json = {
            name: error.name,
            message: error.message
        };
        be = boom.create(_1.getErrorStatusCode(error), error.message);
        be.output.payload.details = {
            name: error.name
        };
        let errors = error.errors;
        if (errors)
            be.output.payload.details.errors = errors;
        ctx.status = _1.getErrorStatusCode(error);
        ctx.body = JSON.stringify(json);
    }
    else {
        be = boom.wrap(error, 500);
    }
    ctx.status = be.output.statusCode;
    ctx.body = be.output.payload;
}
exports.handleError = handleError;
