"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../../errors");
function respondError(res, error) {
    return res.status(errors_1.getErrorStatusCode(error)).json({
        name: error.name,
        message: error.message
    });
}
exports.respondError = respondError;
