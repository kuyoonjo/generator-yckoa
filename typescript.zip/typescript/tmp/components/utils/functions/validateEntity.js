"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _1 = require("../");
function validateEntity(entity) {
    if (!entity) {
        throw new _1.EntityNotFoundError();
    }
}
exports.validateEntity = validateEntity;
