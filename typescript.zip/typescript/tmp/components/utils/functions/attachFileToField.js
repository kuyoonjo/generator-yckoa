"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function attachFileToField(entity, file, field) {
    return new Promise((resolve, reject) => {
        entity['attach'](field, { path: file.path }, error => {
            if (error)
                return reject({
                    name: error.name,
                    message: error.message
                });
            return resolve(entity);
        });
    });
}
exports.attachFileToField = attachFileToField;
