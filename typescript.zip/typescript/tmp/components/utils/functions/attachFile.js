"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const attachFileToField_1 = require("./attachFileToField");
const errors_1 = require("../../errors");
function attachFile(req, entity, field) {
    return __awaiter(this, void 0, void 0, function* () {
        if (req.body[field])
            throw new errors_1.FileUploadError(`Field '${field}' is not a valid file`);
        if (!req.files || !req.files[field] || !req.files[field].length) {
            return entity;
        }
        return yield attachFileToField_1.attachFileToField(entity, req.files[field][0], field);
    });
}
exports.attachFile = attachFile;
