"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
function createEntity(model, req) {
    let entity = new model();
    if (req.body._id)
        delete req.body._id;
    entity = _.merge(entity, req.body);
    return entity;
}
exports.createEntity = createEntity;
