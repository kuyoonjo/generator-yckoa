"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const attachFileToField_1 = require("./attachFileToField");
function attachFiles(req, entity, field) {
    // if (req.body[field])
    //   throw new FileUploadError(`Field '${field}' is not a valid file array`)
    if (!req.files || !req.files[field] || !req.files[field].length) {
        req.files = req.files || {};
        req.files[field] = [];
    }
    if (req['prepareFiles'] && req['prepareFiles'][field]) {
        return Promise.all(req.files[field].reverse().map(file => attachFileToField_1.attachFileToField(entity, file, field)))
            .then(() => {
            for (let i = 0; i < req['prepareFiles'][field].length; i++) {
                switch (req['prepareFiles'][field][i]) {
                    case 0:
                        entity[field][i] = entity[field].pop();
                        break;
                    case 1:
                        entity[field].splice(i, 0, entity[field].pop());
                        break;
                    case -1:
                        entity[field].splice(i, 1);
                        break;
                }
            }
            return entity;
        });
    }
    return Promise.all(req.files[field].map(file => attachFileToField_1.attachFileToField(entity, file, field)))
        .then(() => entity);
}
exports.attachFiles = attachFiles;
