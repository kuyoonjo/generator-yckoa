"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function prepareFiles(req, entity, field) {
    if (req.body[field]) {
        if (req.body[field].constructor !== Array)
            req.body[field] = [req.body[field]];
        req['prepareFiles'] = req['prepareFiles'] || {};
        req['prepareFiles'][field] = req.body[field].map(x => parseInt(x));
        delete req.body[field];
    }
    return entity;
}
exports.prepareFiles = prepareFiles;
